﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fgh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 f3 = new Form2();

            f3.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "агенствоDataSet5.Риэлтор". При необходимости она может быть перемещена или удалена.
            this.риэлторTableAdapter3.Fill(this.агенствоDataSet5.Риэлтор);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "агенствоDataSet4.Риэлтор". При необходимости она может быть перемещена или удалена.
            this.риэлторTableAdapter2.Fill(this.агенствоDataSet4.Риэлтор);

            MessageBox.Show("ДОБРО ПОЖАЛОВАТЬ");
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.риэлторTableAdapter.FillBy(this.агенствоDataSet.Риэлтор);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }
    }
}
